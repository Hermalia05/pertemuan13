package com.informatika.databarang

class RegisterActivity {
}