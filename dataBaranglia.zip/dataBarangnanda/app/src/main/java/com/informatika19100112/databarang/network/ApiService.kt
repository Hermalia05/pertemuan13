package com.informatika19100099.databarang.network

import android.telecom.Call
import com.informatika19100099.databarang.model.ResponseuserItem
import retrofit2.http.GET




interface ApiService {
    @GET("users"
    fun getData (): Call<List<ResponseuserItem?>?
}